#ifndef _PHP_WIN32_UNISTD_H
#define _PHP_WIN32_UNISTD_H
PHPAPI int usleep(unsigned int useconds);
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: sw=4 ts=4 fdm=marker
 * vim<600: sw=4 ts=4
 */
